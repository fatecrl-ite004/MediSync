export function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    CONFIRMED: "Confirmada",
    SCHEDULED: "Agendada",
    COMPLETED: "Concluída",
    CANCELLED_BY_PATIENT: "Cancelada pelo paciente",
    CANCELLED_BY_DOCTOR: "Cancelada pelo médico",
    RESCHEDULED: "Reagendada",
    NO_SHOW: "Não compareceu"
  };

  const kind =
    status.includes("CANCELLED") ? "danger" :
    status === "CONFIRMED" ? "success" :
    status === "COMPLETED" ? "neutral" :
    "warning";

  return <span className={`badge ${kind}`}>{labels[status] || status}</span>;
}
