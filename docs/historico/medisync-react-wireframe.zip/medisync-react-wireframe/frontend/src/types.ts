export type Role = "PATIENT" | "DOCTOR";

export interface User {
  id: number;
  name: string;
  role: Role;
}

export interface Specialty {
  id: number;
  name: string;
  icon: string;
}

export interface Doctor {
  id: number;
  name: string;
  specialtyId: number;
  specialty: string;
  crm: string;
  bio: string;
  rating: number;
  availability: string[];
}

export interface Appointment {
  id: number;
  patientId: number;
  patientName: string;
  doctorId: number;
  doctorName: string;
  specialty: string;
  startsAt: string;
  status: string;
}

export interface Message {
  id: number;
  senderId: number;
  senderRole: Role;
  senderName: string;
  content: string;
  createdAt: string;
}

export interface Conversation {
  id: number;
  appointmentId: number;
  patientId: number;
  doctorId: number;
  status: string;
  expiresAt: string;
  messages: Message[];
}
