import { FormEvent, useEffect, useMemo, useState } from "react";
import { request } from "./api";
import { ThemeToggle } from "./components/ThemeToggle";
import { StatusBadge } from "./components/StatusBadge";
import type { Appointment, Conversation, Doctor, Specialty, User } from "./types";

type Page =
  | "home"
  | "doctors"
  | "booking"
  | "appointments"
  | "conversations"
  | "conversation"
  | "agenda"
  | "profile";

function formatDate(value: string) {
  return new Date(value).toLocaleString("pt-BR", {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [page, setPage] = useState<Page>("home");
  const [theme, setTheme] = useState<"light" | "dark">(
    () => (localStorage.getItem("medisync-theme") as "light" | "dark") || "light"
  );

  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedSpecialty, setSelectedSpecialty] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedTime, setSelectedTime] = useState("");
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [toast, setToast] = useState("");

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("medisync-theme", theme);
  }, [theme]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 2800);
    return () => clearTimeout(timer);
  }, [toast]);

  async function loadData(currentUser: User) {
    const [specialtyData, doctorData, appointmentData, conversationData] =
      await Promise.all([
        request<Specialty[]>("/specialties"),
        request<Doctor[]>("/doctors"),
        request<Appointment[]>(
          `/appointments?role=${currentUser.role}&userId=${currentUser.id}`
        ),
        request<Conversation[]>(
          `/conversations?role=${currentUser.role}&userId=${currentUser.id}`
        )
      ]);

    setSpecialties(specialtyData);
    setDoctors(doctorData);
    setAppointments(appointmentData);
    setConversations(conversationData);
  }

  async function login(role: "patient" | "doctor") {
    const logged = await request<User>("/login", {
      method: "POST",
      body: JSON.stringify({ role })
    });
    setUser(logged);
    setPage("home");
    await loadData(logged);
  }

  async function chooseDoctor(id: number) {
    const doctor = await request<Doctor>(`/doctors/${id}`);
    setSelectedDoctor(doctor);
    setSelectedTime("");
    setPage("booking");
  }

  async function confirmBooking() {
    if (!user || !selectedDoctor || !selectedTime) return;

    try {
      const appointment = await request<Appointment>("/appointments", {
        method: "POST",
        body: JSON.stringify({
          patientId: user.id,
          patientName: user.name,
          doctorId: selectedDoctor.id,
          startsAt: selectedTime
        })
      });

      setAppointments(current => [appointment, ...current]);
      setSelectedTime("");
      setPage("appointments");
      setToast("Consulta confirmada com sucesso.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Erro ao agendar.");
    }
  }

  async function cancelAppointment(id: number) {
    if (!user) return;
    try {
      const updated = await request<Appointment>(`/appointments/${id}/cancel`, {
        method: "PATCH",
        body: JSON.stringify({ role: user.role })
      });
      setAppointments(current =>
        current.map(item => (item.id === updated.id ? updated : item))
      );
      setToast("Consulta cancelada.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Erro ao cancelar.");
    }
  }

  async function openConversation(id: number) {
    const conversation = await request<Conversation>(`/conversations/${id}`);
    setCurrentConversation(conversation);
    setPage("conversation");
  }

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user || !currentConversation) return;

    const form = new FormData(event.currentTarget);
    const content = String(form.get("message") || "").trim();
    if (!content) return;

    try {
      const message = await request<any>(
        `/conversations/${currentConversation.id}/messages`,
        {
          method: "POST",
          body: JSON.stringify({
            senderId: user.id,
            senderRole: user.role,
            senderName: user.name,
            content
          })
        }
      );

      setCurrentConversation(current =>
        current ? { ...current, messages: [...current.messages, message] } : current
      );
      event.currentTarget.reset();
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Erro ao enviar.");
    }
  }

  async function closeConversation() {
    if (!user || !currentConversation) return;
    const updated = await request<Conversation>(
      `/conversations/${currentConversation.id}/close`,
      {
        method: "PATCH",
        body: JSON.stringify({ closedBy: user.id })
      }
    );

    setCurrentConversation(updated);
    setConversations(current =>
      current.map(item => (item.id === updated.id ? updated : item))
    );
    setToast("Conversa encerrada.");
  }

  const filteredDoctors = useMemo(
    () =>
      selectedSpecialty
        ? doctors.filter(d => d.specialtyId === Number(selectedSpecialty))
        : doctors,
    [doctors, selectedSpecialty]
  );

  if (!user) {
    return (
      <>
        <div className="login-shell">
          <header className="login-top">
            <div className="brand">Medi<span>Sync</span></div>
            <ThemeToggle
              theme={theme}
              onToggle={() => setTheme(theme === "light" ? "dark" : "light")}
            />
          </header>

          <main className="login-main">
            <section className="login-copy">
              <span className="eyebrow">Wireframe funcional</span>
              <h1>Atendimento médico mais simples, conectado e contínuo.</h1>
              <p>
                Um protótipo do MediSync para validar busca, agendamento,
                acompanhamento e conversa pós-consulta.
              </p>
            </section>

            <section className="role-grid">
              <button className="role-card" onClick={() => login("patient")}>
                <span className="role-icon">☺</span>
                <strong>Paciente</strong>
                <span>Entrar como João Silva</span>
              </button>

              <button className="role-card" onClick={() => login("doctor")}>
                <span className="role-icon">✚</span>
                <strong>Médico</strong>
                <span>Entrar como Dra. Ana Martins</span>
              </button>
            </section>
          </main>
        </div>

        {toast && <div className="toast">{toast}</div>}
      </>
    );
  }

  const nav =
    user.role === "DOCTOR"
      ? [
          ["home", "⌂", "Painel"],
          ["agenda", "▣", "Agenda"],
          ["conversations", "◌", "Conversas"],
          ["profile", "○", "Perfil"]
        ]
      : [
          ["home", "⌂", "Início"],
          ["doctors", "⌕", "Médicos"],
          ["appointments", "▣", "Consultas"],
          ["conversations", "◌", "Conversas"],
          ["profile", "○", "Perfil"]
        ];

  function renderPatientHome() {
    const next = appointments.find(a => a.status === "CONFIRMED");

    return (
      <>
        <section className="hero card">
          <span className="eyebrow">Olá, {user?.name.split(" ")[0]}</span>
          <h1>Seu cuidado, organizado em um só lugar.</h1>
          <p>Encontre especialistas, agende consultas e acompanhe seu atendimento.</p>
          <div className="actions">
            <button className="btn primary" onClick={() => setPage("doctors")}>
              Agendar consulta
            </button>
            <button className="btn" onClick={() => setPage("appointments")}>
              Minhas consultas
            </button>
          </div>
        </section>

        <div className="section-heading">
          <h2>Próxima consulta</h2>
        </div>

        {next ? (
          <article className="card appointment-highlight">
            <div>
              <StatusBadge status={next.status} />
              <h3>{next.doctorName}</h3>
              <p>{next.specialty}</p>
              <span className="muted">{formatDate(next.startsAt)}</span>
            </div>
            <div className="actions">
              <button className="btn" onClick={() => setPage("appointments")}>
                Ver consulta
              </button>
              <button className="btn danger" onClick={() => cancelAppointment(next.id)}>
                Cancelar
              </button>
            </div>
          </article>
        ) : (
          <div className="card">Nenhuma consulta futura.</div>
        )}

        <div className="section-heading">
          <h2>Especialidades</h2>
        </div>

        <div className="specialty-grid">
          {specialties.map(item => (
            <button
              className="specialty-card"
              key={item.id}
              onClick={() => {
                setSelectedSpecialty(String(item.id));
                setPage("doctors");
              }}
            >
              <span>{item.icon}</span>
              <strong>{item.name}</strong>
            </button>
          ))}
        </div>
      </>
    );
  }

  function renderDoctors() {
    return (
      <>
        <div className="page-heading">
          <div>
            <span className="eyebrow">Agendamento</span>
            <h1>Encontre um profissional</h1>
            <p className="muted">Filtre por especialidade e escolha um horário.</p>
          </div>
        </div>

        <div className="card filters">
          <label htmlFor="specialty">Especialidade</label>
          <select
            id="specialty"
            value={selectedSpecialty}
            onChange={e => setSelectedSpecialty(e.target.value)}
          >
            <option value="">Todas</option>
            {specialties.map(item => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>
        </div>

        <div className="doctor-grid">
          {filteredDoctors.map(doctor => (
            <article className="card doctor-card" key={doctor.id}>
              <div className="doctor-row">
                <div className="doctor-avatar">
                  {doctor.name.replace("Dra. ", "").replace("Dr. ", "").charAt(0)}
                </div>
                <div>
                  <h3>{doctor.name}</h3>
                  <p className="muted">{doctor.specialty}</p>
                </div>
              </div>
              <p>{doctor.bio}</p>
              <div className="doctor-meta">★ {doctor.rating} · {doctor.crm}</div>
              <button className="btn primary full" onClick={() => chooseDoctor(doctor.id)}>
                Ver horários
              </button>
            </article>
          ))}
        </div>
      </>
    );
  }

  function renderBooking() {
    if (!selectedDoctor) return renderDoctors();

    return (
      <>
        <button className="btn ghost" onClick={() => setPage("doctors")}>← Voltar</button>

        <div className="page-heading">
          <div>
            <span className="eyebrow">{selectedDoctor.specialty}</span>
            <h1>{selectedDoctor.name}</h1>
            <p className="muted">Escolha um horário disponível.</p>
          </div>
        </div>

        <div className="card">
          <div className="time-grid">
            {selectedDoctor.availability.map(time => (
              <button
                key={time}
                className={`time-button ${selectedTime === time ? "selected" : ""}`}
                onClick={() => setSelectedTime(time)}
              >
                {formatDate(time)}
              </button>
            ))}
          </div>

          {selectedTime && (
            <div className="booking-summary">
              <div>
                <span className="eyebrow">Resumo</span>
                <h3>Confirme sua consulta</h3>
              </div>
              <dl>
                <div><dt>Médico</dt><dd>{selectedDoctor.name}</dd></div>
                <div><dt>Especialidade</dt><dd>{selectedDoctor.specialty}</dd></div>
                <div><dt>Horário</dt><dd>{formatDate(selectedTime)}</dd></div>
              </dl>
              <button className="btn primary" onClick={confirmBooking}>
                Confirmar consulta
              </button>
            </div>
          )}
        </div>
      </>
    );
  }

  function renderAppointments() {
    return (
      <>
        <div className="page-heading">
          <div>
            <span className="eyebrow">Histórico</span>
            <h1>Minhas consultas</h1>
          </div>
          <button className="btn primary" onClick={() => setPage("doctors")}>
            Nova consulta
          </button>
        </div>

        <div className="card list">
          {appointments.map(item => (
            <article className="list-row" key={item.id}>
              <div>
                <strong>{item.doctorName}</strong>
                <span>{item.specialty}</span>
                <span className="muted">{formatDate(item.startsAt)}</span>
              </div>
              <div className="row-end">
                <StatusBadge status={item.status} />
                {item.status === "CONFIRMED" && (
                  <button className="btn danger" onClick={() => cancelAppointment(item.id)}>
                    Cancelar
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      </>
    );
  }

  function renderConversations() {
    return (
      <>
        <div className="page-heading">
          <div>
            <span className="eyebrow">Acompanhamento</span>
            <h1>Conversas pós-consulta</h1>
            <p className="muted">Canal temporário entre paciente e médico.</p>
          </div>
        </div>

        <div className="card list">
          {conversations.map(item => (
            <article className="list-row" key={item.id}>
              <div>
                <strong>{user.role === "DOCTOR" ? "João Silva" : "Dra. Ana Martins"}</strong>
                <span className="muted">Disponível até {formatDate(item.expiresAt)}</span>
              </div>
              <div className="row-end">
                <span className={`badge ${item.status === "ACTIVE" ? "success" : "neutral"}`}>
                  {item.status === "ACTIVE" ? "Ativa" : "Encerrada"}
                </span>
                <button className="btn" onClick={() => openConversation(item.id)}>
                  Abrir
                </button>
              </div>
            </article>
          ))}
        </div>
      </>
    );
  }

  function renderConversation() {
    if (!currentConversation) return renderConversations();

    return (
      <>
        <button className="btn ghost" onClick={() => setPage("conversations")}>
          ← Conversas
        </button>

        <section className="card chat-shell">
          <header className="chat-header">
            <div>
              <h2>{user.role === "DOCTOR" ? "João Silva" : "Dra. Ana Martins"}</h2>
              <p className="muted">
                Acompanhamento disponível até {formatDate(currentConversation.expiresAt)}
              </p>
            </div>
            <span className={`badge ${currentConversation.status === "ACTIVE" ? "success" : "neutral"}`}>
              {currentConversation.status === "ACTIVE" ? "Ativa" : "Encerrada"}
            </span>
          </header>

          <div className="messages">
            {currentConversation.messages.map(message => (
              <div
                key={message.id}
                className={`message ${message.senderId === user.id ? "mine" : ""}`}
              >
                <strong>{message.senderName}</strong>
                <span>{message.content}</span>
              </div>
            ))}
          </div>

          {currentConversation.status === "ACTIVE" ? (
            <>
              <form className="chat-form" onSubmit={sendMessage}>
                <label className="sr-only" htmlFor="message">Mensagem</label>
                <input id="message" name="message" placeholder="Escreva sua mensagem..." />
                <button className="btn primary" type="submit">Enviar</button>
              </form>
              <button className="btn danger close-chat" onClick={closeConversation}>
                Encerrar conversa
              </button>
            </>
          ) : (
            <div className="closed-note">
              Conversa encerrada. O histórico permanece disponível para leitura.
            </div>
          )}
        </section>
      </>
    );
  }

  function renderDoctorHome() {
    const confirmed = appointments.filter(item => item.status === "CONFIRMED");

    return (
      <>
        <section className="hero card">
          <span className="eyebrow">Área médica</span>
          <h1>Olá, {user.name}.</h1>
          <p>Visualize sua agenda e acompanhe pacientes após a consulta.</p>
        </section>

        <div className="kpi-grid">
          <article className="card kpi-card">
            <span>Consultas</span><strong>{appointments.length}</strong>
          </article>
          <article className="card kpi-card">
            <span>Confirmadas</span><strong>{confirmed.length}</strong>
          </article>
          <article className="card kpi-card">
            <span>Conversas abertas</span>
            <strong>{conversations.filter(c => c.status === "ACTIVE").length}</strong>
          </article>
        </div>

        <div className="section-heading"><h2>Próximos pacientes</h2></div>
        <div className="card list">
          {confirmed.map(item => (
            <div className="list-row" key={item.id}>
              <div>
                <strong>{item.patientName}</strong>
                <span className="muted">{formatDate(item.startsAt)}</span>
              </div>
              <StatusBadge status={item.status} />
            </div>
          ))}
        </div>
      </>
    );
  }

  function renderAgenda() {
    const doctor = doctors.find(item => item.id === user.id);

    return (
      <>
        <div className="page-heading">
          <div>
            <span className="eyebrow">Disponibilidade</span>
            <h1>Minha agenda</h1>
          </div>
        </div>

        <div className="card">
          <h2>Horários disponíveis</h2>
          <div className="time-grid">
            {doctor?.availability.map(time => (
              <span className="time-static" key={time}>{formatDate(time)}</span>
            ))}
          </div>
        </div>

        <div className="section-heading"><h2>Consultas</h2></div>
        <div className="card list">
          {appointments.map(item => (
            <div className="list-row" key={item.id}>
              <div>
                <strong>{item.patientName}</strong>
                <span className="muted">{formatDate(item.startsAt)}</span>
              </div>
              <StatusBadge status={item.status} />
            </div>
          ))}
        </div>
      </>
    );
  }

  function renderProfile() {
    return (
      <section className="card profile-card">
        <div className="profile-avatar">{user.name.charAt(0)}</div>
        <div>
          <span className="eyebrow">{user.role === "DOCTOR" ? "Médico" : "Paciente"}</span>
          <h1>{user.name}</h1>
          <p className="muted">Perfil demonstrativo do wireframe.</p>
        </div>
        <button
          className="btn"
          onClick={() => {
            setUser(null);
            setPage("home");
          }}
        >
          Sair da demonstração
        </button>
      </section>
    );
  }

  let content;
  if (user.role === "DOCTOR") {
    content =
      page === "agenda" ? renderAgenda() :
      page === "conversations" ? renderConversations() :
      page === "conversation" ? renderConversation() :
      page === "profile" ? renderProfile() :
      renderDoctorHome();
  } else {
    content =
      page === "doctors" ? renderDoctors() :
      page === "booking" ? renderBooking() :
      page === "appointments" ? renderAppointments() :
      page === "conversations" ? renderConversations() :
      page === "conversation" ? renderConversation() :
      page === "profile" ? renderProfile() :
      renderPatientHome();
  }

  return (
    <>
      <div className="app-shell">
        <aside className="sidebar">
          <div className="brand">Medi<span>Sync</span></div>
          <nav>
            {nav.map(([target, icon, label]) => (
              <button
                key={target}
                className={page === target ? "active" : ""}
                onClick={() => setPage(target as Page)}
              >
                <span>{icon}</span>{label}
              </button>
            ))}
          </nav>
        </aside>

        <main className="content">
          <header className="topbar">
            <div className="mobile-brand brand">Medi<span>Sync</span></div>
            <div className="topbar-actions">
              <ThemeToggle
                theme={theme}
                onToggle={() => setTheme(theme === "light" ? "dark" : "light")}
              />
              <div className="user-pill">
                <span className="avatar">{user.name.charAt(0)}</span>
                <span>{user.name}</span>
              </div>
            </div>
          </header>

          <div className="page">{content}</div>
        </main>

        <nav className="mobile-nav">
          {nav.map(([target, icon, label]) => (
            <button
              key={target}
              className={page === target ? "active" : ""}
              onClick={() => setPage(target as Page)}
            >
              <span>{icon}</span>
              <small>{label}</small>
            </button>
          ))}
        </nav>
      </div>

      {toast && <div className="toast">{toast}</div>}
    </>
  );
}

export default App;
