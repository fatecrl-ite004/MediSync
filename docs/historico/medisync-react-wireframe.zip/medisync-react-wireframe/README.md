# MediSync — Wireframe Funcional React + TypeScript

Protótipo funcional do MediSync para validação de UX, fluxos e regras sem banco de dados.

## Inclui

- React + TypeScript + Vite
- Tema claro/escuro com preferência salva no navegador
- Interface responsiva
- Login demonstrativo
- Perfis de paciente e médico
- Busca de médicos por especialidade
- Agendamento
- Cancelamento
- Histórico
- Dashboard médico
- Agenda médica
- Chat pós-consulta
- Backend Node.js + Express
- Dados apenas em memória

## Executar

### Backend

```bash
cd backend
npm install
npm run dev
```

Backend:
`http://localhost:3000`

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend:
`http://localhost:5173`

## Observação

Os dados são apagados quando o backend reinicia.

## Próximos passos sugeridos

- recepcionista
- reagendamento
- notificações
- fila de espera
- PostgreSQL
- Prisma
- autenticação real
- WebSocket/Socket.IO
