const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const specialties = [
  { id: 1, name: "Cardiologia", icon: "♥" },
  { id: 2, name: "Dermatologia", icon: "✦" },
  { id: 3, name: "Ortopedia", icon: "◆" },
  { id: 4, name: "Clínica Geral", icon: "✚" }
];

const doctors = [
  {
    id: 1,
    name: "Dra. Ana Martins",
    specialtyId: 1,
    crm: "CRM-SP 123456",
    bio: "Atendimento humanizado com foco em prevenção cardiovascular.",
    rating: 4.9,
    availability: ["2026-09-11T09:00", "2026-09-11T10:30", "2026-09-12T14:00"]
  },
  {
    id: 2,
    name: "Dr. Carlos Mendes",
    specialtyId: 2,
    crm: "CRM-SP 234567",
    bio: "Dermatologia clínica e acompanhamento de rotina.",
    rating: 4.8,
    availability: ["2026-09-11T13:30", "2026-09-12T08:30", "2026-09-12T09:30"]
  },
  {
    id: 3,
    name: "Dra. Beatriz Lima",
    specialtyId: 4,
    crm: "CRM-SP 345678",
    bio: "Clínica geral, prevenção e acompanhamento contínuo.",
    rating: 4.7,
    availability: ["2026-09-11T11:00", "2026-09-12T15:30", "2026-09-13T10:00"]
  }
];

const users = {
  patient: { id: 101, name: "João Silva", role: "PATIENT" },
  doctor: { id: 1, name: "Dra. Ana Martins", role: "DOCTOR" }
};

let appointments = [
  {
    id: 1,
    patientId: 101,
    patientName: "João Silva",
    doctorId: 1,
    doctorName: "Dra. Ana Martins",
    specialty: "Cardiologia",
    startsAt: "2026-09-11T09:00",
    status: "CONFIRMED"
  },
  {
    id: 2,
    patientId: 101,
    patientName: "João Silva",
    doctorId: 1,
    doctorName: "Dra. Ana Martins",
    specialty: "Cardiologia",
    startsAt: "2026-09-05T14:30",
    status: "COMPLETED"
  }
];

let conversations = [
  {
    id: 1,
    appointmentId: 2,
    patientId: 101,
    doctorId: 1,
    status: "ACTIVE",
    expiresAt: "2026-09-15T23:59:00",
    messages: [
      {
        id: 1,
        senderId: 1,
        senderRole: "DOCTOR",
        senderName: "Dra. Ana Martins",
        content: "Olá, João. Como você está se sentindo após a consulta?",
        createdAt: "2026-09-06T10:00:00"
      },
      {
        id: 2,
        senderId: 101,
        senderRole: "PATIENT",
        senderName: "João Silva",
        content: "Estou melhor. Fiquei com uma dúvida sobre os cuidados que conversamos.",
        createdAt: "2026-09-06T10:04:00"
      }
    ]
  }
];

app.get("/api/health", (req, res) => res.json({ ok: true, project: "MediSync" }));

app.post("/api/login", (req, res) => {
  const { role } = req.body;
  res.json(role === "doctor" ? users.doctor : users.patient);
});

app.get("/api/specialties", (req, res) => res.json(specialties));

app.get("/api/doctors", (req, res) => {
  const specialtyId = Number(req.query.specialtyId);
  const result = doctors
    .filter(d => !specialtyId || d.specialtyId === specialtyId)
    .map(d => ({
      ...d,
      specialty: specialties.find(s => s.id === d.specialtyId)?.name
    }));
  res.json(result);
});

app.get("/api/doctors/:id", (req, res) => {
  const doctor = doctors.find(d => d.id === Number(req.params.id));
  if (!doctor) return res.status(404).json({ message: "Médico não encontrado." });
  res.json({
    ...doctor,
    specialty: specialties.find(s => s.id === doctor.specialtyId)?.name
  });
});

app.get("/api/appointments", (req, res) => {
  const role = req.query.role;
  const userId = Number(req.query.userId);

  res.json(
    appointments.filter(a =>
      role === "DOCTOR" ? a.doctorId === userId : a.patientId === userId
    )
  );
});

app.post("/api/appointments", (req, res) => {
  const { patientId, patientName, doctorId, startsAt } = req.body;
  const doctor = doctors.find(d => d.id === Number(doctorId));

  if (!doctor) return res.status(404).json({ message: "Médico não encontrado." });

  if (!doctor.availability.includes(startsAt)) {
    return res.status(409).json({ message: "Esse horário não está disponível." });
  }

  const conflict = appointments.some(
    a =>
      a.doctorId === Number(doctorId) &&
      a.startsAt === startsAt &&
      ["SCHEDULED", "CONFIRMED"].includes(a.status)
  );

  if (conflict) {
    return res.status(409).json({
      message: "Esse horário acabou de ser reservado."
    });
  }

  const specialty = specialties.find(s => s.id === doctor.specialtyId)?.name;

  const appointment = {
    id: Date.now(),
    patientId,
    patientName,
    doctorId: doctor.id,
    doctorName: doctor.name,
    specialty,
    startsAt,
    status: "CONFIRMED"
  };

  appointments.push(appointment);
  res.status(201).json(appointment);
});

app.patch("/api/appointments/:id/cancel", (req, res) => {
  const appointment = appointments.find(a => a.id === Number(req.params.id));
  if (!appointment) return res.status(404).json({ message: "Consulta não encontrada." });

  if (appointment.status === "COMPLETED") {
    return res.status(400).json({ message: "Consulta concluída não pode ser cancelada." });
  }

  appointment.status =
    req.body.role === "DOCTOR"
      ? "CANCELLED_BY_DOCTOR"
      : "CANCELLED_BY_PATIENT";

  res.json(appointment);
});

app.get("/api/conversations", (req, res) => {
  const role = req.query.role;
  const userId = Number(req.query.userId);

  res.json(
    conversations.filter(c =>
      role === "DOCTOR" ? c.doctorId === userId : c.patientId === userId
    )
  );
});

app.get("/api/conversations/:id", (req, res) => {
  const conversation = conversations.find(c => c.id === Number(req.params.id));
  if (!conversation) return res.status(404).json({ message: "Conversa não encontrada." });
  res.json(conversation);
});

app.post("/api/conversations/:id/messages", (req, res) => {
  const conversation = conversations.find(c => c.id === Number(req.params.id));
  if (!conversation) return res.status(404).json({ message: "Conversa não encontrada." });

  if (conversation.status !== "ACTIVE") {
    return res.status(400).json({ message: "Conversa encerrada." });
  }

  const message = {
    id: Date.now(),
    senderId: req.body.senderId,
    senderRole: req.body.senderRole,
    senderName: req.body.senderName,
    content: String(req.body.content || "").trim(),
    createdAt: new Date().toISOString()
  };

  if (!message.content) {
    return res.status(400).json({ message: "Digite uma mensagem." });
  }

  conversation.messages.push(message);
  res.status(201).json(message);
});

app.patch("/api/conversations/:id/close", (req, res) => {
  const conversation = conversations.find(c => c.id === Number(req.params.id));
  if (!conversation) return res.status(404).json({ message: "Conversa não encontrada." });

  conversation.status = "CLOSED";
  conversation.closedBy = req.body.closedBy;
  conversation.closedAt = new Date().toISOString();

  res.json(conversation);
});

app.listen(PORT, () => {
  console.log(`MediSync API em http://localhost:${PORT}`);
});
