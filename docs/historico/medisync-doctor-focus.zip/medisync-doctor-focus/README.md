# MediSync — Doctor Focus

Versão focada na área do médico.

## Recursos
- Perfil profissional estilo rede social
- Foto, capa, descrição, especialidades, catálogo, experiência e formação
- Dashboard com consultas marcadas no centro e histórico de chats logo abaixo
- Chat pela própria consulta
- Chat aberto, prioritário e oculto
- Tema claro/noturno
- Narrador, alto contraste e texto ampliado
- FAQ e suporte
- Backend em memória, sem banco

## Executar no PowerShell

Backend:
```powershell
cd backend
npm.cmd install
npm.cmd run dev
```

Frontend:
```powershell
cd frontend
npm.cmd install
npm.cmd run dev
```

Frontend: http://localhost:5173  
Backend: http://localhost:3000
