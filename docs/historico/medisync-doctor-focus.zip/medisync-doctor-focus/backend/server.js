const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3000;

const doctor = {
  id: 1,
  userId: 1,
  name: "Dra. Ana Martins",
  role: "DOCTOR",
  crm: "CRM-SP 123456",
  headline: "Cardiologista • Prevenção cardiovascular • Acompanhamento contínuo",
  city: "São Paulo",
  state: "SP",
  profilePhoto: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=500&q=80",
  coverPhoto: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1400&q=80",
  about: "Atuo em cardiologia clínica com foco em prevenção, acompanhamento de hipertensão, check-up cardiovascular e orientação contínua ao paciente.",
  specialties: ["Cardiologia","Cardiologia Preventiva","Hipertensão","Check-up cardiovascular"],
  services: [
    { id: 1, title: "Consulta cardiológica", description: "Avaliação clínica inicial e orientação individual.", durationMinutes: 50 },
    { id: 2, title: "Retorno", description: "Revisão de evolução e acompanhamento do plano definido.", durationMinutes: 30 },
    { id: 3, title: "Acompanhamento preventivo", description: "Consulta periódica focada em prevenção cardiovascular.", durationMinutes: 40 }
  ],
  experiences: [
    { id: 1, institution: "Clínica Vida Plena", role: "Cardiologista", period: "2023 — Atual" },
    { id: 2, institution: "Hospital Central", role: "Médica Cardiologista", period: "2020 — 2023" }
  ],
  education: [
    { id: 1, institution: "Universidade de São Paulo", title: "Residência em Cardiologia", period: "2018 — 2020" },
    { id: 2, institution: "Faculdade de Medicina", title: "Medicina", period: "2012 — 2017" }
  ]
};

const patient = { id: 101, name: "João Silva", role: "PATIENT" };

let settings = {
  doctorId: 1,
  theme: "light",
  narratorEnabled: false,
  chatNotifications: true,
  chatMode: "OPEN",
  highContrast: false,
  largerText: false
};

let appointments = [
  { id: 1, patientId: 101, patientName: "João Silva", doctorId: 1, service: "Consulta cardiológica", startsAt: "2026-09-25T09:00:00", status: "CONFIRMED", conversationId: 1 },
  { id: 2, patientId: 102, patientName: "Mariana Costa", doctorId: 1, service: "Retorno", startsAt: "2026-09-25T10:30:00", status: "CONFIRMED", conversationId: null },
  { id: 3, patientId: 103, patientName: "Carlos Henrique", doctorId: 1, service: "Acompanhamento preventivo", startsAt: "2026-09-26T14:00:00", status: "CONFIRMED", conversationId: null },
  { id: 4, patientId: 101, patientName: "João Silva", doctorId: 1, service: "Consulta cardiológica", startsAt: "2026-09-18T15:00:00", status: "COMPLETED", conversationId: 2 }
];

let conversations = [
  {
    id: 1, appointmentId: 1, doctorId: 1, patientId: 101, patientName: "João Silva",
    status: "ACTIVE", startedBy: "DOCTOR", updatedAt: "2026-09-24T20:45:00",
    messages: [
      { id: 1, senderId: 1, senderRole: "DOCTOR", senderName: "Dra. Ana Martins", content: "Olá, João. Se precisar enviar alguma informação antes da consulta, pode responder por aqui.", createdAt: "2026-09-24T20:40:00" }
    ]
  },
  {
    id: 2, appointmentId: 4, doctorId: 1, patientId: 101, patientName: "João Silva",
    status: "CLOSED", startedBy: "PATIENT", updatedAt: "2026-09-19T11:00:00",
    messages: [
      { id: 2, senderId: 101, senderRole: "PATIENT", senderName: "João Silva", content: "Doutora, fiquei com uma dúvida sobre a recomendação da consulta.", createdAt: "2026-09-18T18:20:00" },
      { id: 3, senderId: 1, senderRole: "DOCTOR", senderName: "Dra. Ana Martins", content: "Claro. Vou explicar melhor por aqui.", createdAt: "2026-09-18T18:35:00" }
    ]
  }
];

const faqs = [
  { id: 1, question: "Como alterar o modo de chat?", answer: "Acesse Configurações > Comunicação e escolha Aberto, Oculto ou Prioritário." },
  { id: 2, question: "O que é chat prioritário?", answer: "Somente o médico pode iniciar. Depois de iniciado, o paciente pode responder normalmente." },
  { id: 3, question: "Como usar o narrador?", answer: "Ative o Narrador nas configurações e use o botão Ler página no topo." }
];

function canInitiate(role) {
  if (settings.chatMode === "HIDDEN") return false;
  if (settings.chatMode === "OPEN") return true;
  return settings.chatMode === "PRIORITY" && role === "DOCTOR";
}
function canOpen() { return settings.chatMode !== "HIDDEN"; }

app.get("/api/health", (_, res) => res.json({ ok: true }));
app.post("/api/login", (req, res) => res.json(req.body.role === "patient" ? patient : { id: 1, name: doctor.name, role: "DOCTOR" }));
app.get("/api/doctor/profile", (_, res) => res.json(doctor));
app.get("/api/settings", (_, res) => res.json(settings));
app.patch("/api/settings", (req, res) => {
  settings = { ...settings, ...req.body, doctorId: 1 };
  res.json(settings);
});
app.get("/api/faqs", (_, res) => res.json(faqs));

app.get("/api/appointments", (req, res) => {
  const role = req.query.role;
  const userId = Number(req.query.userId);
  res.json(appointments.filter(a => role === "DOCTOR" ? a.doctorId === userId : a.patientId === userId));
});

app.get("/api/conversations", (req, res) => {
  if (!canOpen()) return res.json([]);
  const role = req.query.role;
  const userId = Number(req.query.userId);
  res.json(conversations.filter(c => role === "DOCTOR" ? c.doctorId === userId : c.patientId === userId));
});

app.get("/api/conversations/:id", (req, res) => {
  if (!canOpen()) return res.status(403).json({ message: "O chat está oculto." });
  const c = conversations.find(x => x.id === Number(req.params.id));
  if (!c) return res.status(404).json({ message: "Conversa não encontrada." });
  res.json(c);
});

app.post("/api/conversations/start", (req, res) => {
  if (!canInitiate(req.body.requesterRole)) {
    return res.status(403).json({
      message: settings.chatMode === "HIDDEN"
        ? "O chat está oculto."
        : "Neste modo, apenas o médico pode iniciar uma conversa."
    });
  }
  const a = appointments.find(x => x.id === Number(req.body.appointmentId));
  if (!a) return res.status(404).json({ message: "Consulta não encontrada." });

  if (a.conversationId) {
    const existing = conversations.find(x => x.id === a.conversationId);
    if (existing) return res.json(existing);
  }

  const c = {
    id: Date.now(),
    appointmentId: a.id,
    doctorId: a.doctorId,
    patientId: a.patientId,
    patientName: a.patientName,
    status: "ACTIVE",
    startedBy: req.body.requesterRole,
    updatedAt: new Date().toISOString(),
    messages: []
  };
  conversations.push(c);
  a.conversationId = c.id;
  res.status(201).json(c);
});

app.post("/api/conversations/:id/messages", (req, res) => {
  if (!canOpen()) return res.status(403).json({ message: "O chat está oculto." });
  const c = conversations.find(x => x.id === Number(req.params.id));
  if (!c) return res.status(404).json({ message: "Conversa não encontrada." });
  if (c.status !== "ACTIVE") return res.status(400).json({ message: "Conversa encerrada." });

  const m = {
    id: Date.now(),
    senderId: req.body.senderId,
    senderRole: req.body.senderRole,
    senderName: req.body.senderName,
    content: String(req.body.content || "").trim(),
    createdAt: new Date().toISOString()
  };
  if (!m.content) return res.status(400).json({ message: "Digite uma mensagem." });

  c.messages.push(m);
  c.updatedAt = m.createdAt;
  res.status(201).json(m);
});

app.listen(PORT, () => console.log(`MediSync API em http://localhost:${PORT}`));
