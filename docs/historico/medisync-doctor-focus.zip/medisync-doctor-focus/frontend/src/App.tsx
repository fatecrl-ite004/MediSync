import { FormEvent, useEffect, useState } from "react";

const API = "http://localhost:3000/api";
async function api(path:string, options:RequestInit={}) {
  const res = await fetch(API+path,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message||"Erro inesperado.");
  return data;
}

type Page = "dashboard"|"profile"|"appointments"|"messages"|"settings";
type User = {id:number;name:string;role:"DOCTOR"|"PATIENT"};

export default function App(){
  const [user,setUser]=useState<User|null>(null);
  const [page,setPage]=useState<Page>("dashboard");
  const [profile,setProfile]=useState<any>(null);
  const [appointments,setAppointments]=useState<any[]>([]);
  const [conversations,setConversations]=useState<any[]>([]);
  const [settings,setSettings]=useState<any>(null);
  const [faqs,setFaqs]=useState<any[]>([]);
  const [current,setCurrent]=useState<any>(null);
  const [toast,setToast]=useState("");

  useEffect(()=>{ if(!toast)return; const t=setTimeout(()=>setToast(""),2600); return()=>clearTimeout(t)},[toast]);
  useEffect(()=>{
    if(!settings)return;
    document.documentElement.dataset.theme=settings.theme;
    document.documentElement.dataset.contrast=settings.highContrast?"high":"normal";
    document.documentElement.dataset.text=settings.largerText?"large":"normal";
  },[settings]);

  async function login(role:"doctor"|"patient"){
    const u=await api("/login",{method:"POST",body:JSON.stringify({role})});
    setUser(u); await load(u); setPage("dashboard");
  }

  async function load(u:User){
    const [p,a,s,f]=await Promise.all([
      api("/doctor/profile"),
      api(`/appointments?role=${u.role}&userId=${u.id}`),
      api("/settings"),
      api("/faqs")
    ]);
    setProfile(p); setAppointments(a); setSettings(s); setFaqs(f);
    setConversations(await api(`/conversations?role=${u.role}&userId=${u.id}`));
  }

  async function saveSettings(patch:any){
    const s=await api("/settings",{method:"PATCH",body:JSON.stringify(patch)});
    setSettings(s); setToast("Configurações atualizadas.");
    if(s.chatMode==="HIDDEN"){setConversations([]);setCurrent(null)}
    else if(user) setConversations(await api(`/conversations?role=${user.role}&userId=${user.id}`));
  }

  async function openChat(id:number){
    try { setCurrent(await api(`/conversations/${id}`)); setPage("messages"); }
    catch(e:any){ setToast(e.message); }
  }

  async function startChat(appointmentId:number){
    try{
      const c=await api("/conversations/start",{method:"POST",body:JSON.stringify({appointmentId,requesterRole:user?.role})});
      setCurrent(c);
      setConversations(old=>old.some(x=>x.id===c.id)?old:[c,...old]);
      setAppointments(old=>old.map(x=>x.id===appointmentId?{...x,conversationId:c.id}:x));
      setPage("messages");
    }catch(e:any){setToast(e.message)}
  }

  async function sendMessage(e:FormEvent<HTMLFormElement>){
    e.preventDefault();
    if(!user||!current)return;
    const fd=new FormData(e.currentTarget), content=String(fd.get("message")||"").trim();
    if(!content)return;
    try{
      const m=await api(`/conversations/${current.id}/messages`,{
        method:"POST",body:JSON.stringify({senderId:user.id,senderRole:user.role,senderName:user.name,content})
      });
      const updated={...current,messages:[...current.messages,m],updatedAt:m.createdAt};
      setCurrent(updated);
      setConversations(old=>old.map(x=>x.id===updated.id?updated:x));
      e.currentTarget.reset();
    }catch(err:any){setToast(err.message)}
  }

  function speak(){
    if(!settings?.narratorEnabled){setToast("Ative o narrador nas configurações.");return}
    speechSynthesis.cancel();
    const text=document.querySelector("main")?.textContent?.replace(/\s+/g," ").trim()||"MediSync";
    const u=new SpeechSynthesisUtterance(text.slice(0,3500));u.lang="pt-BR";speechSynthesis.speak(u);
  }

  if(!user||!profile||!settings){
    return <main className="login">
      <div className="brand">Medi<span>Sync</span></div>
      <section className="login-card">
        <small className="eyebrow">Nova base</small>
        <h1>Área profissional do médico</h1>
        <p>Perfil, consultas, lembretes, chats e configurações em um só lugar.</p>
        <div className="actions">
          <button className="btn primary" onClick={()=>login("doctor")}>Entrar como Dra. Ana</button>
          <button className="btn" onClick={()=>login("patient")}>Testar como paciente</button>
        </div>
      </section>{toast&&<div className="toast">{toast}</div>}
    </main>
  }

  const nav:[Page,string,string][]=[
    ["dashboard","⌂","Painel"],["profile","◉","Perfil"],["appointments","▣","Consultas"],
    ["messages","◌","Mensagens"],["settings","⚙","Configurações"]
  ];
  const upcoming=appointments.filter(a=>a.status==="CONFIRMED");
  const chats=[...conversations].sort((a,b)=>new Date(b.updatedAt).getTime()-new Date(a.updatedAt).getTime());
  const fmt=(v:string)=>new Date(v).toLocaleString("pt-BR",{dateStyle:"medium",timeStyle:"short"});

  const Dashboard=()=> <div>
    <section className="welcome card">
      <div><small className="eyebrow">Área médica</small><h1>Bom atendimento começa antes da consulta.</h1>
      <p>Acompanhe agenda, lembretes e conversas com pacientes.</p></div>
      <button className="btn" onClick={()=>setPage("profile")}>Ver meu perfil</button>
    </section>
    <div className="dash-grid">
      <aside className="card mini">
        <img src={profile.profilePhoto} alt={`Foto de ${profile.name}`}/>
        <h2>{profile.name}</h2><p>{profile.headline}</p><span>{profile.crm}</span>
        <button className="btn full" onClick={()=>setPage("profile")}>Perfil profissional</button>
      </aside>
      <section>
        <div className="title-row"><div><small className="eyebrow">Lembretes</small><h2>Consultas marcadas</h2></div><b>{upcoming.length}</b></div>
        <div className="stack">
          {upcoming.map(a=><article className="card reminder" key={a.id}>
            <div className="datebox"><strong>{new Date(a.startsAt).getDate()}</strong><span>{new Date(a.startsAt).toLocaleDateString("pt-BR",{month:"short"})}</span></div>
            <div><strong>{a.patientName}</strong><span>{a.service}</span><small>{fmt(a.startsAt)}</small></div>
            <div className="actions">
              {a.conversationId
                ? <button className="btn" onClick={()=>openChat(a.conversationId)}>Abrir chat</button>
                : <button className="btn" disabled={settings.chatMode==="HIDDEN"} onClick={()=>startChat(a.id)}>Iniciar chat</button>}
              <button className="btn ghost">Ver consulta</button>
            </div>
          </article>)}
        </div>
        <div className="title-row chats-title"><div><small className="eyebrow">Histórico</small><h2>Chats recentes</h2></div></div>
        {settings.chatMode==="HIDDEN"
          ? <div className="card empty"><strong>Chat oculto</strong><p>O histórico fica indisponível enquanto esse modo estiver ativo.</p></div>
          : <div className="stack">{chats.map(c=><button className="card chat-row" key={c.id} onClick={()=>openChat(c.id)}>
              <span className="avatar">{c.patientName[0]}</span><span><strong>{c.patientName}</strong><small>{c.messages[c.messages.length-1]?.content||"Sem mensagens"}</small></span>
              <time>{new Date(c.updatedAt).toLocaleDateString("pt-BR")}</time>
            </button>)}</div>}
      </section>
      <aside className="card summary">
        <small className="eyebrow">Resumo</small>
        <div><strong>{upcoming.length}</strong><span>consultas futuras</span></div>
        <div><strong>{chats.length}</strong><span>conversas</span></div>
        <div><strong>{profile.services.length}</strong><span>serviços</span></div>
        <div className="policy"><span>Modo do chat</span><strong>{settings.chatMode==="OPEN"?"Aberto":settings.chatMode==="HIDDEN"?"Oculto":"Prioritário"}</strong></div>
      </aside>
    </div>
  </div>;

  const Profile=()=> <div className="profile-grid">
    <section className="stack">
      <article className="card social">
        <div className="cover" style={{backgroundImage:`url(${profile.coverPhoto})`}}/>
        <div className="profile-body">
          <img className="profile-photo" src={profile.profilePhoto} alt={`Foto de ${profile.name}`}/>
          <div className="profile-head"><div><h1>{profile.name}</h1><p>{profile.headline}</p><span>{profile.city}, {profile.state} • {profile.crm}</span></div><button className="btn primary">Editar perfil</button></div>
          <div className="tags">{profile.specialties.map((x:string)=><span key={x}>{x}</span>)}</div>
        </div>
      </article>
      <article className="card section"><h2>Sobre</h2><p>{profile.about}</p></article>
      <article className="card section"><small className="eyebrow">Catálogo</small><h2>Atendimentos</h2>
        <div className="services">{profile.services.map((s:any)=><div className="service" key={s.id}><h3>{s.title}</h3><p>{s.description}</p><span>{s.durationMinutes} minutos</span></div>)}</div>
      </article>
      <article className="card section"><h2>Experiência</h2>{profile.experiences.map((x:any)=><div className="timeline" key={x.id}><b>•</b><div><strong>{x.role}</strong><span>{x.institution}</span><small>{x.period}</small></div></div>)}</article>
      <article className="card section"><h2>Formação</h2>{profile.education.map((x:any)=><div className="timeline" key={x.id}><b>•</b><div><strong>{x.title}</strong><span>{x.institution}</span><small>{x.period}</small></div></div>)}</article>
    </section>
    <aside className="card public-note"><small className="eyebrow">Visualização pública</small><h3>Perfil para pacientes</h3><p>Essa estrutura representa a apresentação profissional do médico dentro do MediSync.</p></aside>
  </div>;

  const Appointments=()=> <div>
    <div className="page-title"><small className="eyebrow">Agenda</small><h1>Consultas</h1></div>
    <div className="card table">{appointments.map(a=><div className="consult-row" key={a.id}>
      <div><strong>{a.patientName}</strong><span>{a.service}</span></div><div><span>{fmt(a.startsAt)}</span><small>{a.status}</small></div>
      <div className="actions">{a.conversationId?<button className="btn" onClick={()=>openChat(a.conversationId)}>Chat</button>:<button className="btn" disabled={settings.chatMode==="HIDDEN"} onClick={()=>startChat(a.id)}>Iniciar chat</button>}<button className="btn ghost">Detalhes</button></div>
    </div>)}</div>
  </div>;

  const Messages=()=> {
    if(settings.chatMode==="HIDDEN") return <div className="card empty"><h1>Chat oculto</h1><p>Nenhum dos lados pode iniciar ou abrir conversas nesse modo.</p><button className="btn" onClick={()=>setPage("settings")}>Alterar configuração</button></div>;
    if(!current) return <div><div className="page-title"><small className="eyebrow">Comunicação</small><h1>Mensagens</h1></div>
      <div className="card list">{chats.map(c=><button className="conversation" key={c.id} onClick={()=>openChat(c.id)}><span className="avatar">{c.patientName[0]}</span><span><strong>{c.patientName}</strong><small>{c.messages[c.messages.length-1]?.content||"Sem mensagens"}</small></span><time>{new Date(c.updatedAt).toLocaleDateString("pt-BR")}</time></button>)}</div>
    </div>;
    return <section className="card chat">
      <header><div><button className="link" onClick={()=>setCurrent(null)}>← Todas as conversas</button><h2>{current.patientName}</h2><span>Consulta #{current.appointmentId}</span></div><b>{current.status==="ACTIVE"?"Ativo":"Encerrado"}</b></header>
      <div className="messages">{current.messages.map((m:any)=><div key={m.id} className={`message ${m.senderId===user.id?"mine":""}`}><strong>{m.senderName}</strong><span>{m.content}</span><small>{fmt(m.createdAt)}</small></div>)}</div>
      {current.status==="ACTIVE"&&<form onSubmit={sendMessage}><input name="message" aria-label="Mensagem" placeholder="Escreva uma mensagem..."/><button className="btn primary">Enviar</button></form>}
    </section>
  };

  const Toggle=({label,desc,keyName}:{label:string;desc:string;keyName:string})=><label className="toggle"><span><strong>{label}</strong><small>{desc}</small></span><input type="checkbox" checked={!!settings[keyName]} onChange={e=>saveSettings({[keyName]:e.target.checked})}/></label>;

  const Settings=()=> <div>
    <div className="page-title"><small className="eyebrow">Preferências</small><h1>Configurações</h1></div>
    <div className="settings-grid">
      <section className="card section"><h2>Aparência e acessibilidade</h2>
        <div className="theme-grid"><button className={settings.theme==="light"?"selected":""} onClick={()=>saveSettings({theme:"light"})}>☀<strong>Claro</strong></button><button className={settings.theme==="dark"?"selected":""} onClick={()=>saveSettings({theme:"dark"})}>☾<strong>Noturno</strong></button></div>
        <Toggle label="Narrador" desc="Habilita leitura do conteúdo da página." keyName="narratorEnabled"/>
        <Toggle label="Alto contraste" desc="Aumenta contraste de textos e bordas." keyName="highContrast"/>
        <Toggle label="Texto ampliado" desc="Aumenta o tamanho base dos textos." keyName="largerText"/>
      </section>
      <section className="card section"><h2>Comunicação</h2>
        <Toggle label="Notificações de chat" desc="Controla avisos de novas mensagens." keyName="chatNotifications"/>
        <div className="modes">
          <button className={settings.chatMode==="OPEN"?"selected":""} onClick={()=>saveSettings({chatMode:"OPEN"})}><strong>Chat aberto</strong><span>Ambos podem iniciar.</span></button>
          <button className={settings.chatMode==="PRIORITY"?"selected":""} onClick={()=>saveSettings({chatMode:"PRIORITY"})}><strong>Chat prioritário</strong><span>Só o médico inicia; depois o paciente responde.</span></button>
          <button className={settings.chatMode==="HIDDEN"?"selected":""} onClick={()=>saveSettings({chatMode:"HIDDEN"})}><strong>Chat oculto</strong><span>Ninguém pode iniciar ou abrir.</span></button>
        </div>
      </section>
      <section className="card section faq"><h2>Suporte e FAQ</h2>{faqs.map(f=><details key={f.id}><summary>{f.question}</summary><p>{f.answer}</p></details>)}<button className="btn full">Entrar em contato com o suporte</button></section>
    </div>
  </div>;

  const content=page==="profile"?<Profile/>:page==="appointments"?<Appointments/>:page==="messages"?<Messages/>:page==="settings"?<Settings/>:<Dashboard/>;

  return <>
    <div className="app">
      <aside className="sidebar">
        <div className="brand">Medi<span>Sync</span></div>
        <div className="side-user"><img src={profile.profilePhoto} alt=""/><span><strong>{profile.name}</strong><small>{profile.crm}</small></span></div>
        <nav>{nav.map(([target,icon,label])=><button key={target} className={page===target?"active":""} onClick={()=>{setCurrent(null);setPage(target)}}><span>{icon}</span>{label}</button>)}</nav>
        <div className="side-bottom">Chat: <strong>{settings.chatMode==="OPEN"?"Aberto":settings.chatMode==="HIDDEN"?"Oculto":"Prioritário"}</strong></div>
      </aside>
      <main>
        <header className="topbar"><span className="mobile-brand">MediSync</span><div className="top-actions">
          {settings.narratorEnabled&&<button className="btn" onClick={speak}>🔊 Ler página</button>}
          <button className="icon" aria-label="Alternar tema" onClick={()=>saveSettings({theme:settings.theme==="light"?"dark":"light"})}>{settings.theme==="light"?"☾":"☀"}</button>
          <button className="user-pill" onClick={()=>setPage("profile")}><img src={profile.profilePhoto} alt=""/><span>{profile.name}</span></button>
        </div></header>
        <div className="wrap">{content}</div>
      </main>
      <nav className="mobile-nav">{nav.map(([target,icon,label])=><button key={target} className={page===target?"active":""} onClick={()=>{setCurrent(null);setPage(target)}}><span>{icon}</span><small>{label}</small></button>)}</nav>
    </div>
    {toast&&<div className="toast">{toast}</div>}
  </>
}
