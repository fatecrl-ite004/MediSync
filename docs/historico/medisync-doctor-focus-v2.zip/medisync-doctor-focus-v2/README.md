# MediSync — Doctor Focus v0.4

Nova base do protótipo, ainda sem banco de dados, focada na área médica.

## Novidades desta versão

- Telemedicina com salas de voz e vídeo
- Apenas o médico pode criar e encerrar salas
- Paciente pode entrar em uma sala criada para sua consulta
- Base WebRTC + Socket.IO para chamada entre dois navegadores
- Chat em tempo real inspirado no WhatsApp
- Confirmação de entrega e leitura
- Apenas o médico pode desativar sua confirmação de leitura
- Chat aberto, prioritário e oculto
- Silenciar notificações por conversa
- Central de notificações
- Notificações configuráveis por categoria:
  - consultas
  - mensagens
  - telemedicina
  - sistema
- Sistema básico de denúncia
- Feedback:
  - reclamação
  - pedido
  - sugestão
- Avaliação de 1 a 5 estrelas após consulta concluída
- Médico avalia paciente e paciente avalia médico
- Modo claro/noturno
- Narrador
- Alto contraste
- Texto ampliado
- Perfil profissional do médico mantido

## Executar

### Backend

```powershell
cd backend
npm.cmd install
npm.cmd run dev
```

Backend:
http://localhost:3000

### Frontend

```powershell
cd frontend
npm.cmd install
npm.cmd run dev
```

Frontend:
http://localhost:5173

## Teste da telemedicina

Para testar dois participantes ao mesmo tempo:

1. Abra o MediSync normalmente e entre como médica.
2. Abra outra janela anônima/incógnita e entre como paciente.
3. Como médica, vá em Telemedicina e crie uma sala para João Silva.
4. No navegador do paciente, a sala ficará disponível.
5. Entre nos dois lados e autorize câmera/microfone.

O protótipo usa WebRTC com STUN público. Para produção, será necessário HTTPS, autenticação real, autorização por consulta, TURN server, expiração segura de sala e uma revisão completa de privacidade/LGPD.

## Observação

Todos os dados continuam em memória. Ao reiniciar o backend, alterações, mensagens, salas, denúncias, feedbacks e avaliações são perdidos.
