# MediSync — Wireframe Funcional

Protótipo simples para testar o fluxo do TCC MediSync sem banco de dados.

## O que existe

- Login demonstrativo por perfil: paciente e médico
- Dashboard do paciente
- Busca de médicos
- Filtro por especialidade
- Agendamento de consulta
- Cancelamento de consulta
- Histórico / lista de consultas
- Chat pós-consulta
- Dashboard básico do médico
- Agenda do médico
- API REST em Node.js + Express
- Dados armazenados somente em memória

> Ao reiniciar o backend, agendamentos e mensagens criados durante o teste são apagados.

## Requisitos

- Node.js 18+

## Como executar

Abra dois terminais.

### 1. Backend

```bash
cd backend
npm install
npm run dev
```

Servidor:

```text
http://localhost:3000
```

### 2. Frontend

Você pode usar qualquer servidor HTTP simples.

Com Python:

```bash
cd frontend
python -m http.server 5500
```

Depois abra:

```text
http://localhost:5500
```

Também funciona com a extensão Live Server do VS Code.

## Usuários de demonstração

Não há senha real neste protótipo.

Escolha na tela:

- Paciente — João Silva
- Médico — Dra. Ana Martins

## Estrutura

```text
medisync-wireframe/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
└── backend/
    ├── package.json
    └── server.js
```

## Próximas evoluções

1. TypeScript
2. React
3. PostgreSQL
4. Prisma
5. autenticação real
6. controle de autorização por perfil
7. recepcionista
8. notificações
9. fila de espera
10. WebSocket/Socket.IO para chat em tempo real
