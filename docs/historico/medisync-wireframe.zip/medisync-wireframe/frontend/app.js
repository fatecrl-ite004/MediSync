const API = "http://localhost:3000/api";

const state = {
  user: null,
  page: "home",
  specialties: [],
  doctors: [],
  appointments: [],
  conversations: [],
  selectedSpecialty: "",
  selectedDoctor: null,
  selectedTime: null
};

const app = document.querySelector("#app");
const toast = document.querySelector("#toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 2800);
}

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Erro inesperado.");
  return data;
}

function formatDate(dateText) {
  const d = new Date(dateText);
  return d.toLocaleString("pt-BR", {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function appointmentBadge(status) {
  const map = {
    CONFIRMED: ["Confirmada", "success"],
    SCHEDULED: ["Agendada", "success"],
    COMPLETED: ["Concluída", ""],
    CANCELLED_BY_PATIENT: ["Cancelada pelo paciente", "danger"],
    CANCELLED_BY_DOCTOR: ["Cancelada pelo médico", "danger"],
    RESCHEDULED: ["Reagendada", "warning"],
    NO_SHOW: ["Não compareceu", "warning"]
  };
  const [label, cls] = map[status] || [status, ""];
  return `<span class="badge ${cls}">${label}</span>`;
}

async function login(role) {
  state.user = await api("/login", {
    method: "POST",
    body: JSON.stringify({ role })
  });
  state.page = "home";
  await loadBaseData();
  render();
}

async function loadBaseData() {
  state.specialties = await api("/specialties");
  state.doctors = await api("/doctors");
  state.appointments = await api(
    `/appointments?role=${state.user.role}&userId=${state.user.id}`
  );
  state.conversations = await api(
    `/conversations?role=${state.user.role}&userId=${state.user.id}`
  );
}

function logout() {
  state.user = null;
  state.page = "home";
  render();
}

function setPage(page) {
  state.page = page;
  render();
}

function navItems() {
  if (state.user.role === "DOCTOR") {
    return [
      ["home", "⌂", "Painel"],
      ["agenda", "▣", "Agenda"],
      ["conversations", "◌", "Conversas"],
      ["profile", "○", "Perfil"]
    ];
  }
  return [
    ["home", "⌂", "Início"],
    ["doctors", "⌕", "Médicos"],
    ["appointments", "▣", "Consultas"],
    ["conversations", "◌", "Conversas"],
    ["profile", "○", "Perfil"]
  ];
}

function layout(content) {
  const nav = navItems();
  return `
    <div class="layout">
      <aside class="sidebar">
        <div class="brand">Medi<span>Sync</span></div>
        <nav aria-label="Navegação principal">
          ${nav.map(([page, icon, label]) => `
            <button
              class="nav-btn ${state.page === page ? "active" : ""}"
              onclick="setPage('${page}')"
            >${icon} ${label}</button>
          `).join("")}
          <button class="nav-btn" onclick="logout()">↪ Sair</button>
        </nav>
      </aside>

      <main class="main">
        <div class="topbar">
          <div>
            <strong>MediSync</strong>
            <div class="muted">${state.user.role === "DOCTOR" ? "Área médica" : "Área do paciente"}</div>
          </div>
          <div class="user-chip">
            <div class="avatar">${state.user.name.slice(0, 1)}</div>
            <span>${state.user.name}</span>
          </div>
        </div>
        ${content}
      </main>

      <nav class="mobile-nav" aria-label="Navegação mobile">
        ${nav.map(([page, icon, label]) => `
          <button class="${state.page === page ? "active" : ""}" onclick="setPage('${page}')">
            <div>${icon}</div>
            <small>${label}</small>
          </button>
        `).join("")}
      </nav>
    </div>
  `;
}

function renderLogin() {
  app.innerHTML = `
    <main class="login">
      <div class="login-box">
        <div class="login-header">
          <h1>MediSync</h1>
          <p class="muted">
            Wireframe funcional para testar agendamento e acompanhamento médico.
          </p>
        </div>

        <div class="grid grid-2">
          <section class="card role-card">
            <div class="role-icon">☺</div>
            <div>
              <h2>Entrar como paciente</h2>
              <p class="muted">Busque médicos, agende consultas e converse após o atendimento.</p>
            </div>
            <button class="btn primary" onclick="login('patient')">Entrar como João</button>
          </section>

          <section class="card role-card">
            <div class="role-icon">✚</div>
            <div>
              <h2>Entrar como médico</h2>
              <p class="muted">Visualize agenda, pacientes e conversas de acompanhamento.</p>
            </div>
            <button class="btn primary" onclick="login('doctor')">Entrar como Dra. Ana</button>
          </section>
        </div>
      </div>
    </main>
  `;
}

function patientHome() {
  const next = state.appointments.find(a => a.status === "CONFIRMED");
  return `
    <section class="page">
      <div class="card hero">
        <p class="muted">Olá, ${state.user.name.split(" ")[0]}.</p>
        <h1>Cuide da sua agenda médica em um só lugar.</h1>
        <p class="muted">Encontre especialistas, acompanhe consultas e mantenha contato após o atendimento.</p>
        <div class="actions">
          <button class="btn primary" onclick="setPage('doctors')">Agendar consulta</button>
          <button class="btn" onclick="setPage('appointments')">Minhas consultas</button>
        </div>
      </div>

      <div class="section-title"><h2>Próxima consulta</h2></div>
      ${next ? `
        <article class="card">
          ${appointmentBadge(next.status)}
          <h3>${next.doctorName}</h3>
          <p>${next.specialty}</p>
          <p class="muted">${formatDate(next.startsAt)}</p>
          <div class="actions">
            <button class="btn" onclick="setPage('appointments')">Ver consulta</button>
            <button class="btn danger" onclick="cancelAppointment(${next.id})">Cancelar</button>
          </div>
        </article>
      ` : `<div class="card"><p>Nenhuma consulta futura encontrada.</p></div>`}

      <div class="section-title"><h2>Especialidades</h2></div>
      <div class="grid grid-3">
        ${state.specialties.map(s => `
          <button class="card btn" onclick="filterSpecialty(${s.id})">${s.name}</button>
        `).join("")}
      </div>
    </section>
  `;
}

function doctorsPage() {
  const filtered = state.selectedSpecialty
    ? state.doctors.filter(d => d.specialtyId === Number(state.selectedSpecialty))
    : state.doctors;

  return `
    <section class="page">
      <div class="section-title">
        <div>
          <h1>Encontrar médico</h1>
          <p class="muted">Selecione uma especialidade e um horário disponível.</p>
        </div>
      </div>

      <div class="field card">
        <label for="specialty">Especialidade</label>
        <select id="specialty" class="select" onchange="changeSpecialty(this.value)">
          <option value="">Todas as especialidades</option>
          ${state.specialties.map(s => `
            <option value="${s.id}" ${String(s.id) === String(state.selectedSpecialty) ? "selected" : ""}>
              ${s.name}
            </option>
          `).join("")}
        </select>
      </div>

      <div class="section-title"><h2>Profissionais</h2></div>
      <div class="grid grid-2">
        ${filtered.map(d => `
          <article class="card doctor-card">
            <div class="doctor-head">
              <div class="doctor-avatar">${d.name.replace("Dra. ", "").replace("Dr. ", "").slice(0, 1)}</div>
              <div>
                <h3>${d.name}</h3>
                <div class="muted">${d.specialty}</div>
              </div>
            </div>
            <p>${d.bio}</p>
            <div><strong>★ ${d.rating}</strong> · ${d.crm}</div>
            <button class="btn primary" onclick="selectDoctor(${d.id})">Ver horários</button>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function bookingPage() {
  const doctor = state.selectedDoctor;
  if (!doctor) return doctorsPage();

  return `
    <section class="page">
      <button class="btn" onclick="setPage('doctors')">← Voltar</button>

      <div class="section-title">
        <div>
          <h1>Agendar com ${doctor.name}</h1>
          <p class="muted">${doctor.specialty}</p>
        </div>
      </div>

      <article class="card">
        <h2>Escolha um horário</h2>
        <div class="times">
          ${doctor.availability.map(time => `
            <button
              class="time-btn ${state.selectedTime === time ? "selected" : ""}"
              onclick="selectTime('${time}')"
              aria-pressed="${state.selectedTime === time}"
            >${formatDate(time)}</button>
          `).join("")}
        </div>

        ${state.selectedTime ? `
          <div class="section-title"><h3>Resumo</h3></div>
          <p><strong>Médico:</strong> ${doctor.name}</p>
          <p><strong>Especialidade:</strong> ${doctor.specialty}</p>
          <p><strong>Data:</strong> ${formatDate(state.selectedTime)}</p>
          <button class="btn primary" onclick="confirmBooking()">Confirmar consulta</button>
        ` : ""}
      </article>
    </section>
  `;
}

function appointmentsPage() {
  return `
    <section class="page">
      <div class="section-title">
        <div>
          <h1>Minhas consultas</h1>
          <p class="muted">Acompanhe consultas futuras e atendimentos anteriores.</p>
        </div>
        <button class="btn primary" onclick="setPage('doctors')">Nova consulta</button>
      </div>

      <div class="card list">
        ${state.appointments.length ? state.appointments.map(a => `
          <article class="list-item">
            <div>
              <strong>${a.doctorName}</strong>
              <div class="muted">${a.specialty}</div>
              <div>${formatDate(a.startsAt)}</div>
            </div>
            <div>
              ${appointmentBadge(a.status)}
              ${a.status === "CONFIRMED"
                ? `<button class="btn danger" onclick="cancelAppointment(${a.id})">Cancelar</button>`
                : ""}
            </div>
          </article>
        `).join("") : `<p>Nenhuma consulta encontrada.</p>`}
      </div>
    </section>
  `;
}

function conversationsPage() {
  return `
    <section class="page">
      <div class="section-title">
        <div>
          <h1>Conversas pós-consulta</h1>
          <p class="muted">Canal temporário para dúvidas após o atendimento.</p>
        </div>
      </div>

      <div class="card list">
        ${state.conversations.length ? state.conversations.map(c => {
          const appointment = state.appointments.find(a => a.id === c.appointmentId);
          return `
            <article class="list-item">
              <div>
                <strong>${state.user.role === "DOCTOR" ? "João Silva" : (appointment?.doctorName || "Médico")}</strong>
                <div class="muted">Disponível até ${formatDate(c.expiresAt)}</div>
              </div>
              <div class="actions">
                <span class="badge ${c.status === "ACTIVE" ? "success" : ""}">${c.status === "ACTIVE" ? "Ativa" : "Encerrada"}</span>
                <button class="btn" onclick="openConversation(${c.id})">Abrir</button>
              </div>
            </article>
          `;
        }).join("") : `<p>Você ainda não possui conversas.</p>`}
      </div>
    </section>
  `;
}

async function openConversation(id) {
  state.currentConversation = await api(`/conversations/${id}`);
  state.page = "conversation";
  render();
}

function conversationPage() {
  const c = state.currentConversation;
  return `
    <section class="page">
      <button class="btn" onclick="setPage('conversations')">← Conversas</button>

      <article class="card chat">
        <header class="chat-header">
          <h2>${state.user.role === "DOCTOR" ? "João Silva" : "Dra. Ana Martins"}</h2>
          <div class="muted">Acompanhamento pós-consulta · até ${formatDate(c.expiresAt)}</div>
        </header>

        <div class="messages" id="messages">
          ${c.messages.map(m => `
            <div class="message ${m.senderId === state.user.id ? "me" : ""}">
              <strong>${m.senderName}</strong>
              <div>${escapeHtml(m.content)}</div>
            </div>
          `).join("")}
        </div>

        ${c.status === "ACTIVE" ? `
          <form class="chat-form" onsubmit="sendMessage(event)">
            <label class="sr-only" for="messageInput">Mensagem</label>
            <input
              id="messageInput"
              class="input"
              autocomplete="off"
              placeholder="Escreva sua mensagem..."
            />
            <button class="btn primary" type="submit">Enviar</button>
          </form>
        ` : `
          <div class="badge">Conversa encerrada — histórico disponível para leitura.</div>
        `}
      </article>

      ${c.status === "ACTIVE" ? `
        <div class="section-title">
          <button class="btn danger" onclick="closeConversation()">Encerrar conversa</button>
        </div>
      ` : ""}
    </section>
  `;
}

function doctorHome() {
  const todayAppointments = state.appointments.filter(a => a.status === "CONFIRMED");
  return `
    <section class="page">
      <div class="card hero">
        <p class="muted">Área médica</p>
        <h1>Olá, ${state.user.name}.</h1>
        <p class="muted">Acompanhe sua agenda e as conversas de pós-consulta.</p>
      </div>

      <div class="section-title"><h2>Resumo</h2></div>
      <div class="grid grid-3">
        <article class="card"><div class="muted">Consultas</div><div class="kpi">${state.appointments.length}</div></article>
        <article class="card"><div class="muted">Confirmadas</div><div class="kpi">${todayAppointments.length}</div></article>
        <article class="card"><div class="muted">Conversas abertas</div><div class="kpi">${state.conversations.filter(c => c.status === "ACTIVE").length}</div></article>
      </div>

      <div class="section-title"><h2>Próximos pacientes</h2></div>
      <div class="card list">
        ${todayAppointments.map(a => `
          <article class="list-item">
            <div>
              <strong>${a.patientName}</strong>
              <div class="muted">${formatDate(a.startsAt)}</div>
            </div>
            ${appointmentBadge(a.status)}
          </article>
        `).join("") || "<p>Nenhuma consulta confirmada.</p>"}
      </div>
    </section>
  `;
}

function doctorAgenda() {
  const doctor = state.doctors.find(d => d.id === state.user.id);
  return `
    <section class="page">
      <div class="section-title">
        <div>
          <h1>Minha agenda</h1>
          <p class="muted">Wireframe de disponibilidade. Nesta versão os horários são fixos.</p>
        </div>
      </div>

      <div class="card">
        <h2>Horários disponíveis</h2>
        <div class="times">
          ${(doctor?.availability || []).map(time => `<span class="badge">${formatDate(time)}</span>`).join("")}
        </div>
      </div>

      <div class="section-title"><h2>Consultas</h2></div>
      <div class="card list">
        ${state.appointments.map(a => `
          <div class="list-item">
            <div>
              <strong>${a.patientName}</strong>
              <div>${formatDate(a.startsAt)}</div>
            </div>
            ${appointmentBadge(a.status)}
          </div>
        `).join("")}
      </div>
    </section>
  `;
}

function profilePage() {
  return `
    <section class="page">
      <div class="section-title"><h1>Perfil</h1></div>
      <article class="card">
        <div class="doctor-head">
          <div class="avatar">${state.user.name.slice(0, 1)}</div>
          <div>
            <h2>${state.user.name}</h2>
            <p class="muted">${state.user.role === "DOCTOR" ? "Médico" : "Paciente"}</p>
          </div>
        </div>
        <p>Este é um perfil demonstrativo. Edição de dados e autenticação real entram nas próximas etapas.</p>
        <button class="btn" onclick="logout()">Sair da demonstração</button>
      </article>
    </section>
  `;
}

function render() {
  if (!state.user) return renderLogin();

  let content = "";
  if (state.user.role === "DOCTOR") {
    const doctorPages = {
      home: doctorHome,
      agenda: doctorAgenda,
      conversations: conversationsPage,
      conversation: conversationPage,
      profile: profilePage
    };
    content = (doctorPages[state.page] || doctorHome)();
  } else {
    const patientPages = {
      home: patientHome,
      doctors: doctorsPage,
      booking: bookingPage,
      appointments: appointmentsPage,
      conversations: conversationsPage,
      conversation: conversationPage,
      profile: profilePage
    };
    content = (patientPages[state.page] || patientHome)();
  }

  app.innerHTML = layout(content);

  requestAnimationFrame(() => {
    const messages = document.querySelector("#messages");
    if (messages) messages.scrollTop = messages.scrollHeight;
  });
}

function filterSpecialty(id) {
  state.selectedSpecialty = String(id);
  state.page = "doctors";
  render();
}

function changeSpecialty(id) {
  state.selectedSpecialty = id;
  render();
}

async function selectDoctor(id) {
  state.selectedDoctor = await api(`/doctors/${id}`);
  state.selectedTime = null;
  state.page = "booking";
  render();
}

function selectTime(time) {
  state.selectedTime = time;
  render();
}

async function confirmBooking() {
  try {
    const appointment = await api("/appointments", {
      method: "POST",
      body: JSON.stringify({
        patientId: state.user.id,
        patientName: state.user.name,
        doctorId: state.selectedDoctor.id,
        startsAt: state.selectedTime
      })
    });

    state.appointments.unshift(appointment);
    state.selectedTime = null;
    state.page = "appointments";
    showToast("Consulta confirmada com sucesso.");
    render();
  } catch (error) {
    showToast(error.message);
  }
}

async function cancelAppointment(id) {
  try {
    const updated = await api(`/appointments/${id}/cancel`, {
      method: "PATCH",
      body: JSON.stringify({ role: state.user.role })
    });

    state.appointments = state.appointments.map(a => a.id === updated.id ? updated : a);
    showToast("Consulta cancelada.");
    render();
  } catch (error) {
    showToast(error.message);
  }
}

async function sendMessage(event) {
  event.preventDefault();
  const input = document.querySelector("#messageInput");
  const content = input.value.trim();
  if (!content) return;

  try {
    const message = await api(`/conversations/${state.currentConversation.id}/messages`, {
      method: "POST",
      body: JSON.stringify({
        senderId: state.user.id,
        senderRole: state.user.role,
        senderName: state.user.name,
        content
      })
    });

    state.currentConversation.messages.push(message);
    input.value = "";
    render();
  } catch (error) {
    showToast(error.message);
  }
}

async function closeConversation() {
  try {
    state.currentConversation = await api(`/conversations/${state.currentConversation.id}/close`, {
      method: "PATCH",
      body: JSON.stringify({ closedBy: state.user.id })
    });
    state.conversations = state.conversations.map(c =>
      c.id === state.currentConversation.id ? state.currentConversation : c
    );
    showToast("Conversa encerrada.");
    render();
  } catch (error) {
    showToast(error.message);
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

render();
